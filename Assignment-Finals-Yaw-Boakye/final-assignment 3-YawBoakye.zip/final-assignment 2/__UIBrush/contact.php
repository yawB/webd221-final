<?php include "head.php"; ?>
<body>
<!-- 	// header for navigation -->
	<header>
		<img id="logo" src="images/logo.png" alt="">
		<nav class="main-navigation">
			<span><a id="simple-menu" href="#sidr"><i id="hit" class="fa fa-bars stack-nav"></i></a></span>
			<ul>
				<li><a href="index.php">home</a></li>
				<li><a href="">about us</a></li>
				<li><a href="">services</a></li>
				<li><a href="portfolio.php">portfolio</a></li>
				<li><a class="custom_line" href="contact.php">contact us</a></li>
			</ul>
		</nav>
	</header>

	<?php include "cell-sidr.php"; ?>

	<div class="hero-picture2">
		<h2> Talk <span>To Us</span></h2>
		<p>
			Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio nihil impedit quo facilis est et expedita distinctio minus id quod maxime placeat facere possimus, omnis voluptas assumenda est.
		</p>
	</div>

<!-- 	// Main Content -->
	<section id="uibrush" class="container">
		<h2 class="Contact-Us">Contact Us</h2>
		<p>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.  Lorem ipsum dolor       sit amet, consectetur adipisicing elit, sed do eiusmod tempor  ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum. 
		</p>

		<div class="map">
			<img src="images/map.png" alt="">
		</div>

		<div class="contact-form">
			<h4>Contact Details:</h4>
			<ul>
				<li>
					
					<p><i class="fa fa-phone"></i>(+91) 0975 720 3582</p>
				</li>
				<li>
					
					<p><i class="fa fa-envelope-o"></i>Email@domain.com</p>
				</li>
				<li>
					
					<p><i class="fa fa-map-marker"></i>No.235, New St, 25th Sector, <span>London, England</span>
					</p>
				</li>
				<li>
					<input class="name" type="text" value="Name">
					<input class="email" type="text" value="Email">
					<input class="message" type="text" value="Message">
				</li>
				<li>
					<input class="button" type="button" value="Submit">
					</input>
				</li>

			</ul>

		</div>

		

	</section>

<?php include "footer.php"; ?>