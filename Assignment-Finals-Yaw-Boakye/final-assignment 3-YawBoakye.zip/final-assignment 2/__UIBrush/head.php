<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="UIBrush" content="PSD Templates">
	<meta name="keywords" content="UIBrush">
	<link rel="stylesheet" href="styles/css.css">
	<link href='http://fonts.googleapis.com/css?family=Ubuntu:300,400,500,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="styles/fonts/font-awesome.min.css" type="text/css">
	<link rel="stylesheet" href="javascript/stylesheets/jquery.sidr.light.css">
	<script src="javascript/jquery-1.9.1.min.js"></script>
	<script src="javascript/modernizr.js"></script>
	<script src="javascript/javascript.js"></script>
	<title>UIBrush - Home</title>
</head>