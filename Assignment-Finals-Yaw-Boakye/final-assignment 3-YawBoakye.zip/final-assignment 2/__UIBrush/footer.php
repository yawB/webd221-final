<footer>
		<p>Copyright © 2014 UIBrush.</p>
	</footer>
	<script src="javascript/jquery.sidr.min.js"></script>
</body>
</html>