<?php include "head.php"; ?>
<body>
<!-- 	// header for navigation -->
	<header>
		<img id="logo" src="images/logo.png" alt="">
		<nav class="main-navigation">
			<span><a id="simple-menu" href="#sidr"><i id="hit" class="fa fa-bars stack-nav"></i></a></span>
			<ul>
				<li><a class="custom_line" href="index.php">home</a></li>
				<li><a href="">about us</a></li>
				<li><a href="">services</a></li>
				<li><a href="portfolio.php">portfolio</a></li>
				<li><a href="contact.php">contact us</a></li>
			</ul>
		</nav>
	</header>

	<?php include "cell-sidr.php"; ?>

	<div class="hero-picture">
		<h2> Welcome To UIBrush</h2>
		<h3> We Provide Ultimate Free PSD Templates</h3>
		<i class="fa fa-chevron-left"></i>
		<i class="fa fa-chevron-right"></i>
	</div>

	<section id="mid-banner" class="clearfix">
		<ul id="mid-title" class="container">
			<li>Lorem ipsum dolor sit amet</li>
			<li>consectetuer adipiscing elit</li>
		</ul>
	</section>

<!-- 	// Main Content -->
	<section id="uibrush" class="container ">
		<h2>UIBrush</h2>
		<p>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <br> voluptate velit esse cillum.
		</p>

		<ul>
			<li>
				<i class="fa fa-th-list fa-2x"></i>
				<h2>Innovative Design</h2>
				<p>Lorem ipsum dolor sit amet, consectetur 
				adipisicing elit, sed do eiusmod tempor 
				incididunt ut labore eturet dolore magna  
				aliqua. </p>
			</li>
			<li>
				<i class="fa fa-code"></i>
				<h2>Clean Coding</h2>
				<p>Lorem ipsum dolor sit amet, consectetur  
				adipisicing elit, sed do eiusmod tempor  
				incididunt ut labore eturet dolore magna  
				aliqua. </p>
			</li>
			<li>
				<i class="fa fa-location-arrow"></i>
				<h2>Quick Delivery</h2>
				<p>Lorem ipsum dolor sit amet, consectetur  
				adipisicing elit, sed do eiusmod tempor  
				incididunt ut labore eturet dolore magna  
				aliqua.</p>
			</li>
			<li>
				<i class="fa fa-phone"></i>
				<h2>Best Support</h2>
				<p>Lorem ipsum dolor sit amet, consectetur  
				adipisicing elit, sed do eiusmod tempor  
				incididunt ut labore eturet dolore magna  
				aliqua.</p>
			</li>
		</ul>
		<h2>Recent Projects</h2>
		<p>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut <br> labore eturet dolore magna aliqua. 
		</p>

 	<article class="portfolio">
					
			<div class="sample">
				<img src="images/photo-1.png" alt="">
				<div >
					<h5>Portfolio One</h5>
					<div class="greyLine "></div>
					<p>Lorem ipsum dolor sit amet.</p>
				</div>
			</div>
			<div class="sample">
				<img src="images/photo-2.png" alt="">
				<div>
					<h5>Portfolio Two</h5>
					<div class="greyLine "></div>
					<p>Lorem ipsum dolor sit amet.</p>
				</div>
			</div>
			<div class="sample">
				<img src="images/photo-3.png" alt="">
				<div>
					<h5>Portfolio Three</h5>
					<div class="greyLine "></div>
					<p>Lorem ipsum dolor sit amet.</p>
				</div>
			</div>
			<div class="sample">
				<img src="images/photo-4.png" alt="">
				<div>
					<h5>Portfolio Four</h5>
					<div class="greyLine "></div>
					<p>Lorem ipsum dolor sit amet.</p>
				</div>
			</div>
					
	</article>
	</section>

<?php include "footer.php"; ?>
	