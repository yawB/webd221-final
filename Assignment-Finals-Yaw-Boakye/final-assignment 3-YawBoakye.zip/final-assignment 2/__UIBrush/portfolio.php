<?php include "head.php"; ?>
<body>
<!-- 	// header for navigation -->
	<header>
		<img id="logo" src="images/logo.png" alt="">
		<nav class="main-navigation">
			<span><a id="simple-menu" href="#sidr"><i id="hit" class="fa fa-bars stack-nav"></i></a></span>
			<ul>
				<li><a href="index.php">home</a></li>
				<li><a href="">about us</a></li>
				<li><a href="">services</a></li>
				<li><a class="custom_line" href="portfolio.php">portfolio</a></li>
				<li><a href="contact.php">contact</a></li>
			</ul>
		</nav>
	</header>

	<?php include "cell-sidr.php"; ?>

	<div class="hero-picture3">
		<h2> Our <span>Works</span></h2>
		<p>
			Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio nihil impedit quo facilis est et expedita distinctio minus id quod maxime placeat facere possimus, omnis voluptas assumenda est.
		</p>
	</div>

<!-- 	// Main Content -->
	<section id="uibrush" class="container">
		<h2 class="Our-Portfolio">Our Portfolio</h2>
		<p>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.  Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor  ut labore eturet dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.   
		</p>

	</section>

	<section class="container"> 
		<ul id="second-nav">
			<li>ALL</li>
			<li>HTML</li>
			<li>Jqery</li>
			<li>UI Design</li>
			<li>Wordpress</li>
		</ul>

		<ul id="projects-gallery">
			<li >
				<div id="effect-1" class="effects clearfix">
					<div class="img">
					    <img src="images/p-pic1.png" alt="">
					    <div class="overlay">
					        <a href="#" class="expand"><i class="fa fa-search-plus"></i></a>
					        <p>Project Name</p>
					        <a class="close-overlay hidden"></a>
					    </div>
						</div>
				</div>
			</li>
			<li >
				<div id="effect-1" class="effects clearfix">
					<div class="img">
					    <img src="images/p-pic2.png" alt="">
					    <div class="overlay">
					        <a href="#" class="expand"><i class="fa fa-search-plus"></i></a>
					        <p>Project Name</p>
					        <a class="close-overlay hidden"></a>
					    </div>
						</div>
				</div>
			</li>
			<li >
				<div id="effect-1" class="effects clearfix">
					<div class="img">
					    <img src="images/p-pic3.png" alt="">
					    <div class="overlay">
					        <a href="#" class="expand"><i class="fa fa-search-plus"></i></a>
					        <p>Project Name</p>
					        <a class="close-overlay hidden"></a>
					    </div>
						</div>
				</div>
			</li>
			<li >
				<div id="effect-1" class="effects clearfix">
					<div class="img">
					    <img src="images/p-pic4.png" alt="">
					    <div class="overlay">
					        <a href="#" class="expand"><i class="fa fa-search-plus"></i></a>
					        <p>Project Name</p>
					        <a class="close-overlay hidden"></a>
					    </div>
						</div>
				</div>
			</li>
			<li >
				<div id="effect-1" class="effects clearfix">
					<div class="img">
					    <img src="images/p-pic5.png" alt="">
					    <div class="overlay">
					        <a href="#" class="expand"><i class="fa fa-search-plus"></i></a>
					        <p>Project Name</p>
					        <a class="close-overlay hidden"></a>
					    </div>
						</div>
				</div>
			</li>
			<li >
				<div id="effect-1" class="effects clearfix">
					<div class="img">
					    <img src="images/p-pic6.png" alt="">
					    <div class="overlay">
					        <a href="#" class="expand"><i class="fa fa-search-plus"></i></a>
					        <p>Project Name</p>
					        <a class="close-overlay hidden"></a>
					    </div>
						</div>
				</div>
			</li>
			<li >
				<div id="effect-1" class="effects clearfix">
					<div class="img">
					    <img src="images/p-pic7.png" alt="">
					    <div class="overlay">
					        <a href="#" class="expand"><i class="fa fa-search-plus"></i></a>
					        <p>Project Name</p>
					        <a class="close-overlay hidden"></a>
					    </div>
						</div>
				</div>
			</li>
			<li >
				<div id="effect-1" class="effects clearfix">
					<div class="img">
					    <img src="images/p-pic8.png" alt="">
					    <div class="overlay">
					        <a href="#" class="expand"><i class="fa fa-search-plus"></i></a>
					        <p>Project Name</p>
					        <a class="close-overlay hidden"></a>
					    </div>
						</div>
				</div>
			</li>
			<li >
				<div id="effect-1" class="effects clearfix">
					<div class="img">
					    <img src="images/p-pic9.png" alt="">
					    <div class="overlay">
					        <a href="#" class="expand"><i class="fa fa-search-plus"></i></a>
					        <p>Project Name</p>
					        <a class="close-overlay hidden"></a>
					    </div>
						</div>
				</div>
			</li>
			
		</ul>

	</section>

<?php include "footer.php"; ?>